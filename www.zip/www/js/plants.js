var plants ={
    "10":["cactus","cactus-pot"],
    "20":["aloe-pot","red-pot"],
    "30":["green-grass","tree"],
    "40":["tall-pot","purple-grass"],
    "50":["palm","aloe"],
    "60":["flower","flower-2"]
}